// ─── Site ────────────────────────────────────────────────────────────────────

export interface SiteConfig {
  title: string;
  description: string;
  language: string;
}

export const siteConfig: SiteConfig = {
  title: "Lumora Resin Arts | Handcrafted Resin Creations",
  description: "Discover exquisite handmade resin art including jewelry, wall clocks, keychains, and custom gifts. Each piece is crafted with love and preserved flowers.",
  language: "en",
};

// ─── Navigation ──────────────────────────────────────────────────────────────

export interface MenuLink {
  label: string;
  href: string;
}

export interface SocialLink {
  icon: string;
  label: string;
  href: string;
}

export interface NavigationConfig {
  brandName: string;
  menuLinks: MenuLink[];
  socialLinks: SocialLink[];
  searchPlaceholder: string;
  cartEmptyText: string;
  cartCheckoutText: string;
  continueShoppingText: string;
  menuBackgroundImage: string;
}

export const navigationConfig: NavigationConfig = {
  brandName: "Lumora Resin Arts",
  menuLinks: [
    { label: "Home", href: "#hero" },
    { label: "Products", href: "#products" },
    { label: "About", href: "#about" },
    { label: "Journal", href: "#blog" },
    { label: "Contact", href: "#contact" },
  ],
  socialLinks: [
    { icon: "Instagram", label: "Instagram", href: "https://instagram.com" },
    { icon: "Facebook", label: "Facebook", href: "https://facebook.com" },
    { icon: "Twitter", label: "Twitter", href: "https://twitter.com" },
  ],
  searchPlaceholder: "Search products...",
  cartEmptyText: "Your cart is empty",
  cartCheckoutText: "Checkout",
  continueShoppingText: "Continue Shopping",
  menuBackgroundImage: "/images/menu-bg.jpg",
};

// ─── Hero ────────────────────────────────────────────────────────────────────

export interface HeroConfig {
  tagline: string;
  title: string;
  ctaPrimaryText: string;
  ctaPrimaryTarget: string;
  ctaSecondaryText: string;
  ctaSecondaryTarget: string;
  backgroundImage: string;
}

export const heroConfig: HeroConfig = {
  tagline: "Handcrafted Resin Creations",
  title: "Preserving Nature's\nBeauty in Resin",
  ctaPrimaryText: "Shop Now",
  ctaPrimaryTarget: "#products",
  ctaSecondaryText: "Our Story",
  ctaSecondaryTarget: "#about",
  backgroundImage: "/images/hero-bg.jpg",
};

// ─── SubHero ─────────────────────────────────────────────────────────────────

export interface Stat {
  value: number;
  suffix: string;
  label: string;
}

export interface SubHeroConfig {
  tag: string;
  heading: string;
  bodyParagraphs: string[];
  linkText: string;
  linkTarget: string;
  image1: string;
  image2: string;
  stats: Stat[];
}

export const subHeroConfig: SubHeroConfig = {
  tag: "Our Philosophy",
  heading: "Artistry in Every Drop",
  bodyParagraphs: [
    "At Lumora Resin Arts, we believe in capturing the ephemeral beauty of nature and preserving it forever. Each piece we create tells a unique story of flowers, memories, and artistry.",
    "Our handcrafted resin creations combine traditional craftsmanship with modern design, resulting in timeless pieces that bring joy and elegance to your everyday life."
  ],
  linkText: "Discover Our Process",
  linkTarget: "#video-section",
  image1: "/images/subhero-1.jpg",
  image2: "/images/subhero-2.jpg",
  stats: [
    { value: 500, suffix: "+", label: "Happy Customers" },
    { value: 100, suffix: "%", label: "Handmade" },
    { value: 3, suffix: "+", label: "Years Experience" },
  ],
};

// ─── Video Section ───────────────────────────────────────────────────────────

export interface VideoSectionConfig {
  tag: string;
  heading: string;
  bodyParagraphs: string[];
  ctaText: string;
  ctaTarget: string;
  backgroundImage: string;
}

export const videoSectionConfig: VideoSectionConfig = {
  tag: "The Process",
  heading: "From Flower to Forever",
  bodyParagraphs: [
    "Every piece begins with carefully selected flowers and botanicals. We delicately preserve each petal, leaf, and bloom before encasing them in crystal-clear resin.",
    "Our meticulous process ensures that the natural beauty of each element is captured perfectly, creating a timeless treasure that lasts forever."
  ],
  ctaText: "View Our Collection",
  ctaTarget: "#products",
  backgroundImage: "/images/video-section.jpg",
};

// ─── Products ────────────────────────────────────────────────────────────────

export interface Product {
  id: number;
  name: string;
  price: number;
  category: string;
  image: string;
}

export interface ProductsConfig {
  tag: string;
  heading: string;
  description: string;
  viewAllText: string;
  addToCartText: string;
  addedToCartText: string;
  categories: string[];
  products: Product[];
}

export const productsConfig: ProductsConfig = {
  tag: "Our Collection",
  heading: "Handcrafted with Love",
  description: "Explore our curated collection of resin art pieces, each uniquely crafted with preserved flowers and botanicals.",
  viewAllText: "View All Products",
  addToCartText: "Add to Cart",
  addedToCartText: "Added!",
  categories: ["All", "Jewelry", "Wall Art", "Home Decor", "Gifts"],
  products: [
    { id: 1, name: "Floral Resin Necklace", price: 45, category: "Jewelry", image: "/images/product-necklace.jpg" },
    { id: 2, name: "Botanical Wall Clock", price: 89, category: "Wall Art", image: "/images/product-clock.jpg" },
    { id: 3, name: "Lavender Keychain", price: 25, category: "Gifts", image: "/images/product-keychain.jpg" },
    { id: 4, name: "Ocean Wave Wall Art", price: 120, category: "Wall Art", image: "/images/product-wallart.jpg" },
    { id: 5, name: "Daisy Drop Earrings", price: 35, category: "Jewelry", image: "/images/product-earrings.jpg" },
    { id: 6, name: "Flower Bangle Bracelet", price: 55, category: "Jewelry", image: "/images/product-bracelet.jpg" },
    { id: 7, name: "Botanical Photo Frame", price: 65, category: "Home Decor", image: "/images/product-frame.jpg" },
    { id: 8, name: "Rose Resin Ring", price: 40, category: "Jewelry", image: "/images/product-ring.jpg" },
  ],
};

// ─── Features ────────────────────────────────────────────────────────────────

export interface Feature {
  icon: "Truck" | "ShieldCheck" | "Leaf" | "Heart";
  title: string;
  description: string;
}

export interface FeaturesConfig {
  features: Feature[];
}

export const featuresConfig: FeaturesConfig = {
  features: [
    {
      icon: "Truck",
      title: "Free Shipping",
      description: "Complimentary shipping on all orders over $50"
    },
    {
      icon: "ShieldCheck",
      title: "Quality Guaranteed",
      description: "Each piece is carefully inspected before shipping"
    },
    {
      icon: "Leaf",
      title: "Eco-Friendly",
      description: "Sustainable materials and eco-conscious packaging"
    },
    {
      icon: "Heart",
      title: "Made with Love",
      description: "Every item is handcrafted with attention to detail"
    }
  ],
};

// ─── Blog ────────────────────────────────────────────────────────────────────

export interface BlogPost {
  id: number;
  title: string;
  date: string;
  image: string;
  excerpt: string;
}

export interface BlogConfig {
  tag: string;
  heading: string;
  viewAllText: string;
  readMoreText: string;
  posts: BlogPost[];
}

export const blogConfig: BlogConfig = {
  tag: "Journal",
  heading: "Stories from the Studio",
  viewAllText: "View All Stories",
  readMoreText: "Read More",
  posts: [
    {
      id: 1,
      title: "The Art of Preserving Flowers in Resin",
      date: "February 10, 2026",
      image: "/images/blog-process.jpg",
      excerpt: "Discover the meticulous process behind creating our signature floral resin pieces."
    },
    {
      id: 2,
      title: "Styling Resin Art in Your Home",
      date: "January 28, 2026",
      image: "/images/blog-homedecor.jpg",
      excerpt: "Tips and inspiration for incorporating resin art into your interior design."
    },
    {
      id: 3,
      title: "Choosing the Perfect Botanicals",
      date: "January 15, 2026",
      image: "/images/blog-materials.jpg",
      excerpt: "Learn about the different flowers and plants we use in our creations."
    }
  ],
};

// ─── FAQ ─────────────────────────────────────────────────────────────────────

export interface FaqItem {
  id: number;
  question: string;
  answer: string;
}

export interface FaqConfig {
  tag: string;
  heading: string;
  ctaText: string;
  ctaTarget: string;
  faqs: FaqItem[];
}

export const faqConfig: FaqConfig = {
  tag: "Support",
  heading: "Frequently Asked Questions",
  ctaText: "Still have questions? Contact us",
  ctaTarget: "#contact",
  faqs: [
    {
      id: 1,
      question: "How do I care for my resin jewelry?",
      answer: "To keep your resin pieces looking beautiful, avoid direct sunlight for prolonged periods, clean with a soft cloth, and store in a cool, dry place. Avoid contact with harsh chemicals and remove before swimming or showering."
    },
    {
      id: 2,
      question: "Can I request custom orders?",
      answer: "Absolutely! We love creating custom pieces. You can send us your own flowers or choose from our selection. Contact us through the form below to discuss your custom order."
    },
    {
      id: 3,
      question: "How long does shipping take?",
      answer: "Standard shipping takes 5-7 business days within the country. Express shipping is available for 2-3 business day delivery. International shipping typically takes 10-14 business days."
    },
    {
      id: 4,
      question: "What is your return policy?",
      answer: "We accept returns within 14 days of delivery for unused items in original packaging. Custom orders are non-refundable due to their personalized nature."
    },
    {
      id: 5,
      question: "Are your materials eco-friendly?",
      answer: "Yes! We use eco-friendly resin and sustainable packaging materials. Our flowers are sourced from local gardens and ethically grown suppliers."
    }
  ],
};

// ─── About ───────────────────────────────────────────────────────────────────

export interface AboutSection {
  tag: string;
  heading: string;
  paragraphs: string[];
  quote: string;
  attribution: string;
  image: string;
  backgroundColor: string;
  textColor: string;
}

export interface AboutConfig {
  sections: AboutSection[];
}

export const aboutConfig: AboutConfig = {
  sections: [
    {
      tag: "Our Story",
      heading: "A Journey of Passion",
      paragraphs: [
        "Lumora Resin Arts began with a simple love for flowers and a desire to preserve their fleeting beauty. What started as a small hobby has blossomed into a passion-driven business dedicated to creating timeless resin art pieces.",
        "Each creation is a labor of love, combining artistic vision with meticulous craftsmanship. We believe that every flower has a story to tell, and through resin, we help those stories live on forever."
      ],
      quote: "",
      attribution: "",
      image: "/images/about-studio.jpg",
      backgroundColor: "#8b6d4b",
      textColor: "#ffffff"
    },
    {
      tag: "Our Mission",
      heading: "Crafting Memories",
      paragraphs: [],
      quote: "Every piece we create is not just art—it's a preserved moment, a captured memory, a story told through petals and resin.",
      attribution: "— The Lumora Team",
      image: "/images/about-collection.jpg",
      backgroundColor: "#f7f7f7",
      textColor: "#333333"
    }
  ],
};

// ─── Contact ─────────────────────────────────────────────────────────────────

export interface FormFields {
  nameLabel: string;
  namePlaceholder: string;
  emailLabel: string;
  emailPlaceholder: string;
  messageLabel: string;
  messagePlaceholder: string;
}

export interface ContactConfig {
  heading: string;
  description: string;
  locationLabel: string;
  location: string;
  emailLabel: string;
  email: string;
  phoneLabel: string;
  phone: string;
  formFields: FormFields;
  submitText: string;
  submittingText: string;
  submittedText: string;
  successMessage: string;
  backgroundImage: string;
}

export const contactConfig: ContactConfig = {
  heading: "Get in Touch",
  description: "Have a question or want to place a custom order? We'd love to hear from you. Fill out the form below and we'll get back to you soon.",
  locationLabel: "Visit Us",
  location: "123 Artisan Lane, Creative District, CA 90210",
  emailLabel: "Email",
  email: "hello@lumoraresinarts.com",
  phoneLabel: "Phone",
  phone: "+1 (555) 123-4567",
  formFields: {
    nameLabel: "Your Name",
    namePlaceholder: "Enter your name",
    emailLabel: "Your Email",
    emailPlaceholder: "Enter your email",
    messageLabel: "Your Message",
    messagePlaceholder: "Tell us about your inquiry or custom order..."
  },
  submitText: "Send Message",
  submittingText: "Sending...",
  submittedText: "Sent!",
  successMessage: "Thank you for reaching out! We'll get back to you within 24 hours.",
  backgroundImage: "/images/contact-bg.jpg",
};

// ─── Footer ──────────────────────────────────────────────────────────────────

export interface FooterLink {
  label: string;
  href: string;
}

export interface FooterLinkGroup {
  title: string;
  links: FooterLink[];
}

export interface FooterSocialLink {
  icon: string;
  label: string;
  href: string;
}

export interface FooterConfig {
  brandName: string;
  brandDescription: string;
  newsletterHeading: string;
  newsletterDescription: string;
  newsletterPlaceholder: string;
  newsletterButtonText: string;
  newsletterSuccessText: string;
  linkGroups: FooterLinkGroup[];
  legalLinks: FooterLink[];
  copyrightText: string;
  socialLinks: FooterSocialLink[];
}

export const footerConfig: FooterConfig = {
  brandName: "Lumora Resin Arts",
  brandDescription: "Handcrafted resin art preserving nature's beauty. Each piece tells a unique story of flowers, memories, and artistry.",
  newsletterHeading: "Join Our Newsletter",
  newsletterDescription: "Subscribe for exclusive offers, new arrivals, and behind-the-scenes stories from our studio.",
  newsletterPlaceholder: "Enter your email",
  newsletterButtonText: "Subscribe",
  newsletterSuccessText: "Thank you for subscribing!",
  linkGroups: [
    {
      title: "Shop",
      links: [
        { label: "All Products", href: "#products" },
        { label: "Jewelry", href: "#products" },
        { label: "Wall Art", href: "#products" },
        { label: "Gift Sets", href: "#products" }
      ]
    },
    {
      title: "Company",
      links: [
        { label: "About Us", href: "#about" },
        { label: "Our Process", href: "#video-section" },
        { label: "Journal", href: "#blog" },
        { label: "Contact", href: "#contact" }
      ]
    },
    {
      title: "Support",
      links: [
        { label: "FAQ", href: "#faq" },
        { label: "Shipping Info", href: "#" },
        { label: "Returns", href: "#" },
        { label: "Custom Orders", href: "#contact" }
      ]
    }
  ],
  legalLinks: [
    { label: "Privacy Policy", href: "#" },
    { label: "Terms of Service", href: "#" }
  ],
  copyrightText: "© 2026 Lumora Resin Arts. All rights reserved.",
  socialLinks: [
    { icon: "Instagram", label: "Instagram", href: "https://instagram.com" },
    { icon: "Facebook", label: "Facebook", href: "https://facebook.com" },
    { icon: "Twitter", label: "Twitter", href: "https://twitter.com" }
  ],
};
